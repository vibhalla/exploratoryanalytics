"""
Assgnment 2 Question 3
This program converts Celcius to Fahrenheit
Created on Tue May 14 23:50:49 2019

@author: vishal_bhalla
"""

def main():
    print("This program lists the Celcius to Fahrenheit conversion chart\n")
    print("Celcius    Fahrenheit")
    print("---------------------")
    for celcius in range(0,101,10):
        fahrenheit = ((9/5)*celcius)+32
        print(celcius,"  ", fahrenheit)
    
    
main()