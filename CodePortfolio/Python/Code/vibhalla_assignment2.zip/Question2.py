"""
Assgnment 2 Question 2
This program converts mpg to lts per 100 km
Created on Tue May 14 23:39:22 2019

@author: vishal_bhalla
"""

def main():
    print("This program converts from mileage to liters per 100 km")
    mpg = eval( input("Please enter mileage (miles per gallon): " ))
    kmpl = (mpg*1.6)/3.785
    km100 = 100/kmpl
    print("Vehicle economy is ", mpg , " per gallon." )
    print("Vehicle consumption is ", km100 , " liters per 100 kilometers." )
    
    
main()