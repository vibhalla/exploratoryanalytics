"""
Assgnment 2 Question 4
This program works as a live calculator
Created on Tue May 14 23:59:49 2019

@author: vishal_bhalla
"""

def main():
    print("Welcome to the interactive Python Calculator\n")
    for repetation in range(1,101,1):
        exp = eval( input("Please enter a mathematical expression here: " ))
        print(exp)
    
    
main()