"""
Assgnment 2 Question 1
This program converts kilometers to miles
Created on Tue May 14 23:26:19 2019

@author: vishal_bhalla
"""

def main():
    print("This program converts kilometers to miles.")
    km = eval( input("Enter the distance in Kilometers: " ))
    miles = .62*km
    print("The distance is ", miles , " miles." )
    
    
main()