# -*- coding: utf-8 -*-
"""
Created on Mon May 27 18:52:59 2019
Assignment 4 - Question 1
This program prints a string in the reverse order.
@author: vishal_bhalla
"""

def main():
    outputStr = ""
    print("This program prints a string in the reverse order.")
    inputStr = input("Please enter a string: ")
    for i in range(len(inputStr)-1,-1,-1):
        outputStr = outputStr + inputStr[i]
    print("The string in the reverse order: " , outputStr)
    
main()
