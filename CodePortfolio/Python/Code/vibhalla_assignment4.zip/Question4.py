# -*- coding: utf-8 -*-
"""
Created on Wed May 29 21:32:40 2019
Assignment 4 - Question 4
This program checks if a string is a palindrome.
@author: vishal_bhalla
"""

def main():
    inStrList = []
    outStrList = []
    print("The program checks if an input string is a palindrome.")
    inStr = input("Enter a string: ")
    strLen = len(inStr)
    for i in range(0,strLen,1):
        inStrList = inStr[i]
        outStrList = inStr[strLen - i - 1]
    if (inStrList == outStrList):
        print("The string is a palindrome")
    else:
        print("String is not a palindrome")
    
main()