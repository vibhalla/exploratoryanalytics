# -*- coding: utf-8 -*-
"""
Created on Tue May 28 23:44:15 2019
Assignment 4 - Question 2
This program spells in input number.
@author: vishal_bhalla
"""

def main():
    myNumList = ['zero','one','two','three','four','five','six','seven','eight','nine']
    outputStr = ""
    print("This program spells the input number.")
    inNum = input("Please enter a number: ")
    for i in inNum:
        outputStr = outputStr + myNumList[int(i)]
    print("The number in words: " , outputStr)
    
main()