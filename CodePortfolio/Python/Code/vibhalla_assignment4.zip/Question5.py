# -*- coding: utf-8 -*-
"""
Created on Wed May 29 22:09:37 2019
Assignment 4 - Question 5
This program counts the number of words in the file
@author: vishal_bhalla
"""

def main():
    wordCount = 0
    print("The program counts the number of words in an input file")
    fileName = input("Enter the name of the file: ")
    inFile = open(fileName, "r")
    for line in inFile.readlines():
        inStrList = []
        inStrList = line.split()
        wordCount = wordCount + len(inStrList)
        
        
    print("Number of words in the file is :" , wordCount)
    
main()