# -*- coding: utf-8 -*-
"""
Created on Tue May 28 23:59:15 2019
Assignment 4 - Question 3
This program calculates the numerical value of  string.
@author: vishal_bhalla
"""

def main():
    myStrList = ['a','b','c','d','e','f','g','h','i','j','k','l','m',
                 'n','o','p','q','r','s','t','u','v','w','x','y','z']
    outSum = 0
    print("This program computes the value of a string.")
    inStr = input("Enter any name is lower case: ")
    for i in inStr:
        outSum = outSum + (myStrList.index(i) + 1)
    print("The numeric value of the name is  " , outSum)
    
main()