# -*- coding: utf-8 -*-
"""
Created on Sat Jun 22 17:35:54 2019
Assignment 7 - Question 4
This program prints the prime numbers in a given range
@author: vishal_bhalla
"""

def printPrime(lowerLimit, upperLimit):
    for i in range(lowerLimit,upperLimit, 1):
        numPrime = isPrime(i)
        if numPrime:
            print(i)
        
    
def isPrime(i):
    flag = True
    if (i == 3 or i == 2):
        return flag
    else:
        for n in range(2,i,1):
            if i%n == 0:
                flag = False
                break
    return flag
 


def main():
    print("The program prints prime numbers in a range.")
    try:
        lowerLimit = int(input("Enter the lower limit of a range:"))
        upperLimit = int(input("Enter the upper limit of a range:"))
        if (lowerLimit < 2):
            print("Invalid input: Lower limit should be a positive integer, greater than 1.")
            return
        if (upperLimit < 2):
            print("Invalid input: Upper limit should be a positive integer, greater than 1.")
            return
        if lowerLimit > upperLimit:
            print("Invalid input: Upper limit is less than lower limit.")
            return
        printPrime(lowerLimit, upperLimit)
        
    except ValueError:
        print("Error! You entered a non-integer!")
    

main()