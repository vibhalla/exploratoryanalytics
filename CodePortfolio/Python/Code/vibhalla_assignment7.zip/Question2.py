# -*- coding: utf-8 -*-
"""
Created on Sat Jun 22 14:09:00 2019
Assignment 7 - Question 2
This program checks if input numbers are sorted.
@author: vishal_bhalla
"""

def toNumbers(strList):
    try:
        for i in range(len(strList)):
            strList[i] = int(strList[i])
        return True
    except ValueError:
            return False

def isAscend(nums):
    flag = True
    baseNum = nums[0]
    for i in range(len(nums)):
        if baseNum > nums[i]:
            flag = False
            return flag
        baseNum = nums[i]
    return flag
    
def isDescend(nums):
    flag = True
    baseNum = nums[0]
    for i in range(len(nums)):
        if baseNum < nums[i]:
            flag = False
            return flag
        baseNum = nums[i]
    return flag
    
def areSame(nums):
    flag = True
    baseNum = nums[0]
    for i in range(len(nums)):
        if baseNum != nums[i]:
            flag = False
            return flag
    return flag

def main():
    print("A program to check if the input numbers are sorted")
    strList = input("Enter numbers separated by space:").split()
    convert = toNumbers(strList)
# First convert the list to numbers. If there is an alphanumeric value it throws an error
    if not convert:
        print("Error! The input is not a number!")
        return
    else:
        nums = strList

    if len(nums) == 0:
        print("Error! No input number")
        return
    elif len(nums) == 1:
        print("You entered a single number")
        return
    
    if areSame(nums):
        print("The numbers are same.")
        return
    elif isDescend(nums):
        print("The numbers are in Descending order.")
        return
    elif isAscend(nums):
        print("The numbers are in Ascending order.")
        return
    else:
        print("Numbers are not sorted")
    return


    
main()

