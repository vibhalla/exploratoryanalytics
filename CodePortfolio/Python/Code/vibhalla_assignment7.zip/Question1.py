# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 23:10:19 2019
Assignment 7 - Question 1
This program prints the min, max and the count of positive and negative numbers
@author: vishal_bhalla
"""
def chkNum():
    n = 0
    posNum = 0
    negNum = 0
    minNum = 0
    maxNum = 0
    num = input("Enter a number:")


    while num != "":
        try:
            num = float(num)
            n = n + 1
            if minNum > num:
                minNum = num
            if maxNum < num:
                maxNum = num
            if num > 0:
                posNum = posNum + 1
            if num < 0:
                negNum = negNum + 1
            
            num = input("Enter next number:")
            
        except ValueError:
            num = input("Error! Please enter a valid number:")
    return n,minNum,maxNum,posNum,negNum


def main():
    print("This program prints the min, max and the count of positive and negative numbers")
    n,minNum,maxNum,posNum,negNum = chkNum()
    print("You entered ", n ,"numbers.")
    print("The smallest number is",minNum)
    print("The largest number is", maxNum)
    print("There are ",posNum, " postive and ", negNum, " negative number(s).")
    

main()