# -*- coding: utf-8 -*-
"""
Created on Sat Jun 22 20:55:37 2019
Assignment 7 - Question 5
The program keeps a score and prints winner in a tennis game.
@author: vishal_bhalla
"""
def point():
    returnVal = "E"
    inputVal = input("Who wins a point, player A or player B? ").upper()
    if (inputVal == "A"):
        returnVal = "A" 
    elif (inputVal == "B"):
        returnVal = "B"
    elif (inputVal == "Q"):
        returnVal = "Q"
    else:
        returnVal = "E"
    return returnVal


def game():
    gameCont = True
    scoreA = 0
    scoreB = 0
    while gameCont:
        display(scoreA,scoreB)
        ptWin = point()
        if ptWin == "A":
            scoreA = scoreA + 1
        elif ptWin == "B":
            scoreB = scoreB + 1
        elif ptWin == "Q":
            print("You quit the game.")
            gameCont = False
            return
        else:
            print("Invalid input. Please enter A, B or Q (to quit).")
        
        if ((scoreA >= 4) or (scoreB >= 4)):
            if (abs(scoreA - scoreB) >= 2):
                winner = 'A' if scoreA > scoreB else 'B'
                print("Player ", winner, " wins the game.")
                gameCont = False
    return
                
def display(scoreA,scoreB):
    scrList = ['0','15','30','40']
    dispA = scrList[scoreA] if scoreA <= 3 else '40'
    dispB = scrList[scoreB] if scoreB <= 3 else '40'
    if ((scoreA >= 3) and (scoreB >= 3)):
        if scoreA>scoreB:
            dispA = 'Adv'
            dispB = '' 
        elif scoreA<scoreB:
            dispB = 'Adv'
            dispA = ''
    print("Score of player A: ", dispA)
    print("Score of player B: ", dispB)
    print()    
            

def main():
    print("The program keeps a score and prints winner in a tennis game.")
    game()
    return

main()