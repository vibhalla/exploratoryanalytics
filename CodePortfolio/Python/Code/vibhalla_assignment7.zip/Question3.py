# -*- coding: utf-8 -*-
"""
Created on Sat Jun 22 15:17:18 2019
Assignment 7 - Question 3
This program to sum the rows of an input matrix
@author: vishal_bhalla
"""

def inMatrix():
    mx = []
    numRows = eval(input("Enter the number of rows:"))
    numElem = eval(input("Enter the number of columns:"))
    for i in range(numRows):
        row = []
        for j in range(numElem):
            print("Enter the next elemnt of row",i, ":")
            row.append(eval(input()))
        mx.append(row)
    return mx
        


def printMx(mx):
    print()
    print("Input Matrix")
    for i in range(len(mx)):
        for j in range(len(mx[i])):
            print(mx[i][j],end="\t")
        print()
    print()


def sumRows(mx):
    sums = []
    for i in range(len(mx)):
        x = 0
        for j in range(len(mx[i])):
            x = x + mx[i][j]
        sums.append(x)
    return sums
    
    
def main():
    print("Program to sum the rows of input matrix")
    mx = inMatrix()
    printMx(mx)
    sumList = sumRows(mx)
    for rowInd in range(len(sumList)):
        print("The sum of row ", rowInd, " is " , sumList[rowInd])
        
        
    

main()
    
