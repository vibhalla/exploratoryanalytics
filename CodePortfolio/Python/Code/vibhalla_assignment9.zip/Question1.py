# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 22:52:26 2019
This program reads a csv file and fills the NaN's with 0's
@author: vishal_bhalla
"""

import numpy as np 

def main():
    scores_all = np.genfromtxt("../Data/Scores_all.csv", delimiter = ",")
    scores = scores_all[1:,:]
    scores[np.isnan(scores)] = 0
    scores = scores.astype(np.int)
    print(scores)
    np.save("../Data/scores", scores)
    
main()