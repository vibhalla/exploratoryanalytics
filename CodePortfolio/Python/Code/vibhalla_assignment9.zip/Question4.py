# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 23:41:46 2019
Program to calculate the average score for each assignment
@author: vishal_bhalla
"""

import numpy as np
np.set_printoptions(suppress=True)

def main():
    scores = np.load("../Data/scores.npy")
    scores_only = scores[1:,:]
    scores_only = np.delete(scores_only, (0), axis=1)
    studentCount = len(scores_only)

    averages = np.empty((np.size(scores_only,1),1),dtype=np.float64)
    
    for i in range (np.size(scores_only,1)):
        averages[i:i+1,0:1] = (scores_only[:,i:i+1].sum(axis = 0)/studentCount)
        averages = np.around(averages, decimals=1)
    averages = averages.astype(str)
 
    for i in range(0,6,1):
        print("Homework ", i , " average: ", averages[i,0])
    print()
    j = 6
    for i in range(1,12,1):
        print("Lab ", i , " average: ", averages[j,0])
        j = j + 1
    print()
    j = 19
    for i in range(1,11,1):
        if i != 4:
            print("Quiz ", i , " average: ", averages[j,0])
            j = j + 1
    print()
    print("Final project avg: ",averages[17,0])
    print("Midterm 1 average: ",averages[18,0])
    print("Midterm 2 average: ",averages[28,0])
    print()
    
main()