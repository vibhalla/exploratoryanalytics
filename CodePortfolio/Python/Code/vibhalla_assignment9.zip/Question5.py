# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 08:00:16 2019
Program to calculate assignment wise averages
@author: vishal_bhalla
"""


import numpy as np
np.set_printoptions(suppress=True)

def main():
    print("Program to calculate assignment group averages.")
    print()
    scores = np.load("../Data/scores.npy")
    scores_only = scores[1:,:]
    scores_only = np.delete(scores_only, (0), axis=1)
    studentCount = len(scores_only)
    print("Homework average: ", np.around(scores_only[:,0:6].sum()/(studentCount*6), decimals = 1))
    print("Lab average: ", np.around(scores_only[:,6:17].sum()/(studentCount*11), decimals = 1))
    print("Quiz average: ", np.around(scores_only[:,19:28].sum()/(studentCount*9), decimals = 1))
    print("Project average: ", np.around(scores_only[:,17:18].sum()/(studentCount), decimals = 1))
    print("Midterm 1 average: ", np.around(scores_only[:,18:19].sum()/(studentCount), decimals = 1))
    print("Midterm 2 average: ", np.around(scores_only[:,28:29].sum()/(studentCount), decimals = 1))

main()