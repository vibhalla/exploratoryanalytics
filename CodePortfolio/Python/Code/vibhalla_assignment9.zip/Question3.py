# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 07:57:04 2019
Program to calculate the final grade score
@author: vishal_bhalla
"""

import numpy as np
np.set_printoptions(suppress=True)

def letterGrade(score):
    grade = ''
    if score >= 93:
        grade = 'A'
    elif score >= 90 and score < 93:
        grade = 'A-'
    elif score >= 86 and score < 90:
        grade = 'B+'
    elif score >= 83 and score < 86:
        grade = 'B'
    elif score >= 80 and score < 83:
        grade = 'B-'
    elif score >= 76 and score < 80:
        grade = 'C+'
    elif score >= 73 and score < 76:
        grade = 'C'
    elif score >= 70 and score < 73:
        grade = 'C-'
    elif score >= 67 and score < 70:
        grade = 'D+'
    elif score >= 60 and score < 67:
        grade = 'D'
    else:
        grade = 'F'
    return grade

def main():
    
    score_headings = np.load("../Data/score_headings.npy")
    final_scores = np.zeros((len(score_headings),3))
    final_scores[:,0] = score_headings[:,0]
    final_scores[:,1] = score_headings[:, 1:7].sum(axis = 1)
    final = np.empty((len(final_scores),1),dtype='<U3')
    toLetterGrade = np.vectorize(letterGrade)
    final[:,0] = toLetterGrade(final_scores[:,1])
    final_scores = np.around(final_scores, decimals=1)
    final_scores = final_scores.astype(str)
    final_scores[:,2] = final[:,0]
    print(final_scores)

main()