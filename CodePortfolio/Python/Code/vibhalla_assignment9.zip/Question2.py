# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 23:29:46 2019
A program to read from file and manipulate the data
@author: vishal_bhalla
"""
import numpy as np
np.set_printoptions(suppress=True)
def main():
    scores = np.load("../Data/scores.npy")
    """
    ("ID numbers","Weighted scores for the homework assignment",
                 "Weighted scores for the labs","Weighted final project scores",
                 "Weighted midterm 1 scores","Weighted scores for the quizzes",
                 "Weighted midterm 2 scores")
    """
    scores_only = scores[1:,:]
    score_headings = np.zeros((len(scores_only),7))
    score_headings[:,0] = scores_only[:,0]
    score_headings[:,1] = (scores_only[:, 1:7].sum(axis = 1)/600)*20
    score_headings[:,2] = (scores_only[:, 7:18].sum(axis = 1)/1100)*30
    score_headings[:,3] = (scores_only[:, 18:19].sum(axis = 1)/100)*10
    score_headings[:,4] = (scores_only[:, 19:20].sum(axis = 1)/100)*10
    score_headings[:,5] = (scores_only[:, 20:29].sum(axis = 1)/90)*15
    score_headings[:,6] = (scores_only[:, 29:30].sum(axis = 1)/100)*15
    score_headings = np.around(score_headings, decimals=1)
    print(score_headings)
    np.save("../Data/score_headings", score_headings)

main()
