# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 23:11:55 2019
Calculates correlation between Boeing and Coca Cola closing values in 2016
@author: vishal_bhalla
"""

import pandas as pd
from pandas_datareader import data as web

def stkStd(sData):
    stkVar = 0
    rowCnt, colCnt = sData.shape
    # Calculate and print the average of 2016 closing stock values
    stkAvg = round(sData["Close"].sum()/rowCnt,2)
    # Iterate over the DF and calculate the variance
    for i in range(rowCnt):
        stkVar = stkVar + (((sData["Close"][i] - stkAvg )**2)/(rowCnt - 1))
    #Standard deviation = sqrt(variance)
    stkSD = round(((stkVar)**.5),2)    
    return stkAvg,stkSD

def correl(baStock,koStock):
    coVar = 0
    numRows = koStock.shape[0]
    koAvg, koSD = stkStd(koStock)
    baAvg, baSD = stkStd(baStock)
    
    print("Average Boeing stock value: ",baAvg)
    print("Std deviation of Boeing stock: ",baSD)
    print()
    print("Average Coke stock value: ",koAvg)
    print("Std deviation of Coke stock: ",koSD)
    print()
    
    # Calculate Covariance
    for i in range(numRows):
        coVar = coVar + (((koStock["Close"][i] - koAvg )*(baStock["Close"][i] - baAvg ))/(numRows - 1))
    coVar = round(coVar,2)
    
    #Calculate Correlation
    cor = (coVar/(koSD*baSD))
    
    return cor
    
    
def main():
    print('\nProgram calculates sample correlation between Boeing and',
          'Coca Cola closing stock values in 2016.\n')
    stock1 = web.DataReader("BA", 'yahoo', '1/1/2016', '12/31/2016')
    stock2 = web.DataReader("ko", 'yahoo', '1/1/2016', '12/31/2016')
    corKOBA = correl(stock1,stock2)
    print("Correlation between BA and KO: ",round(corKOBA,2))

main()