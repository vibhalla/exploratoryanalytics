# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 06:15:02 2019
Program to calculates relative standard deviation for 8 Dow Jones companies.
@author: vishal_bhalla
"""
import pandas as pd
from pandas_datareader import data as web

def relStd(sData):
    stkVar = 0
    rowCnt, colCnt = sData.shape
    # Calculate and print the average of 2016 closing stock values
    stkAvg = round(sData["Close"].sum()/rowCnt,2)
    # Iterate over the DF and calculate the variance
    for i in range(rowCnt):
        stkVar = stkVar + (((sData["Close"][i] - stkAvg )**2)/(rowCnt - 1))
    #Standard deviation = sqrt(variance)
    stkSD = ((stkVar)**.5)
    stkRelSD = round(((stkSD/stkAvg)*100),2)
    return stkRelSD
    
def main():
    print("\nProgram that calculates relative standard deviation for eight Dow Jones companies.\n")
    stkSym = {"KO":"Coca Cola", "BA":"Boeing", "PFE":"Pfizer", "VZ":"Verizon",
              "GE":"General Electric",  "JPM":"JP Morgan", "XOM":"Exxon Mobil",
              "IBM":"IBM Corp"}
    stkCal = {}
    for sym in stkSym:
        stkCal[sym] = stkSym[sym]
        sData = web.DataReader(sym, 'yahoo', '1/1/2016', '12/31/2016')
        stkCal[sym] = relStd(sData)
    print("Company \tRelative std deviation")
    for stock in stkCal:
        print(stkSym[stock]," "*(20 - len(stkSym[stock])), stkCal[stock])
main()
