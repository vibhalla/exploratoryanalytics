# -*- coding: utf-8 -*-
"""
Created on Mon Jul  1 07:50:24 2019
Program to calculate IBM stock statistics for the year 2016
@author: vishal_bhalla
"""

import pandas as pd
from pandas_datareader import data as web


def main():
    IBMVar = 0
    print("\nProgram that calculates IBM stock data statistics for year 2016.")
    IBM = web.DataReader("IBM", 'yahoo', '1/1/2016', '12/31/2016')

    rowCnt, colCnt = IBM.shape
    print("There are ", rowCnt, " rows of stock data.")
    # Calculate and print the average of 2016 closing stock values
    IBMAvg = round(IBM["Close"].sum()/rowCnt,2)
    print("\nIBM 2016 average stock value:" , IBMAvg)
    # Iterate over the DF and calculate the variance
    for i in range(rowCnt):
        IBMVar = IBMVar + (((IBM["Close"][i] - IBMAvg )**2)/(rowCnt - 1))
    IBMVar = round(IBMVar,2)
    print("IBM stock variance:          " , IBMVar)
    #Standard deviation = sqrt(variance)
    IBMSd = round(((IBMVar)**.5),2)
    print("IBM stock standard deviation: ", IBMSd)
    print("\nThe max stock value ", round(IBM["Close"].max(),2) ,
          " was on" , IBM["Close"].idxmax().date())
    print("The max stock value ", round(IBM["Close"].min(),2) ,
          " was on" , IBM["Close"].idxmin().date())
main()
