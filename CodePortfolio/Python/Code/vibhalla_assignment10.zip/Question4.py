# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 07:13:11 2019
Program that finds the longest period a stock was up in 2016.
@author: vishal_bhalla
"""
import pandas as pd
from pandas_datareader import data as web

def maxUp(stck):
    stckUp = 0
    tempUp = 0
    strtIdx = 0
    for i in range(1, len(stck)):
        if stck["Close"][i] > stck["Close"][i - 1]:
            tempUp = tempUp + 1
        else:
            if tempUp > stckUp:
                #print(tempUp, stckUp)
                stckUp = tempUp
                strtIdx = i - stckUp
            tempUp = 0
    return stckUp, strtIdx


def main():
    print("\nProgram that finds the longest period a stock was up in 2016.\n")
    stckSym = input("Please enter the stock symbol:")
    df = web.DataReader(stckSym, 'yahoo', '1/1/2016', '12/31/2016')
    upDays, strtIdx = maxUp(df)
    strtDt = df["Close"].index[strtIdx]
    strtDt1 = df["Close"].index[strtIdx - 1]
    endDt = df["Close"].index[strtIdx + upDays -1]

    print("\nThe longest up period for the stock symbol", stckSym.upper(), " :")
    print("Length in days: ", upDays)
    print("Period started on:", strtDt.date())
    print("Close stock value at start:", round(df["Close"][strtDt1],6))
    print("Period ended on:", endDt.date())
    print("Close stock value at end:", round(df["Close"][endDt],6))


main()