# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 22:32:15 2019
Assignment 5 - Question 3
This program prints the possible number of combinations for the number provided
@author: vishal_bhalla
"""

def factorial(nVal):
    fact = 1
    for i in range(1, nVal + 1, 1):
        fact = fact*i
    return fact
        


def main():
    print("Calculates the number of combinations of n objects taken r at a time.")
    nVal = eval(input("Enter a positive integer n: "))
    rVal = eval(input("Enter a positive integer r: "))
    print()
    if (nVal <= 0 or rVal <= 0):
        print("Error! Please enter a positive integer")
        return
    if nVal < rVal:
        print("Error! Number n is less than r!")
        return  

    combo = (factorial(nVal)/(factorial(rVal)*factorial(nVal - rVal)))
    print("Number of combinations C(",nVal,",",rVal,") = ", combo)
    
main()