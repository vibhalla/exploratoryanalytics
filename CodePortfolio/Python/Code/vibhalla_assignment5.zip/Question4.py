# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 23:29:08 2019
Assignment 5 - Question 4
This program prints sum of squares of the numbers
@author: vishal_bhalla
"""

def toNumbers(strList):
    for i in range(len(strList)):
        strList[i] = float(strList[i])
    return strList     
                
    
def squareEach(nums):
    for i in range(len(nums)):
        nums[i] = nums[i]**2
    return nums

    
def sumLists(nums):
    total = 0
    for i in range(len(nums)):
        total = total + nums[i]
    return total

    
def main():
    x = 1
    print("This program prints the sum of squares of each line in the file")
    fileName = input("Enter the name of the file with numbers: ")
    inFile = open(fileName, "r")
    for line in inFile.readlines():
        inStrList = []
        inStrList = line.split()
        inStrList = toNumbers(inStrList)
        inStrList = squareEach(inStrList)
        lineSum = sumLists(inStrList)
        print("The sum of squares of line ",x," is: ", lineSum)
        x = x + 1
    inFile.close()

    
main()