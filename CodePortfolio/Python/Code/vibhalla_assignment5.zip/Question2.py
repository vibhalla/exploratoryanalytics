# -*- coding: utf-8 -*-
"""
Created on Sun Jun  2 22:49:15 2019
Assignment 5 - Question 2
This program prints the X pattern using the character selected
@author: vishal_bhalla
"""

def printX(n,c):
    endChar = 0
    for i in range(n):
        for endChar in range(n):
            if (i == endChar) or ((n - endChar - 1) == i):
                print(c, end='')
            else:
                print(' ', end = '')
        print('')


def main():
    print("This program the letter X using the character supplied")
    nVal = eval(input("Please enter a positive ODD Integer: "))
    ch = input("Character to print: ")
    print()
    if nVal%2 != 1:
        print("You entered a number, which is not a positive ODD integer.")
        return  

    printX(nVal,ch)
    
    
main()

