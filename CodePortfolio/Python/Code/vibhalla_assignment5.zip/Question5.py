# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 00:08:55 2019
Assignment 5 - Question 5
This program counts the number of digits in a line
@author: vishal_bhalla
"""

def countDigits(strLine):
    digitCount = 0
    for i in strLine:
        if i.isdigit():
            digitCount = digitCount + 1
    return digitCount     
                

def main():
    x = 1
    print("This program prints the number of digits in each line of a file")
    fileName = input("Enter the name of the input text file: ")
    print('')
    inFile = open(fileName, "r")
    for line in inFile.readlines():
        numDigit = countDigits(line)
        print("There are ", numDigit, " digits in line ", x)
        x = x + 1
    inFile.close()

    
main()