# -*- coding: utf-8 -*-
"""
Created on Sun Jun  2 09:57:27 2019
Assignment 5 - Question 1
This program sums the first N positive integers and their cubes
@author: vishal_bhalla
"""

def sumN(n):
    total = 0
    for i in range(n+1):
        total = total + i
    return total
    
def sumNCubes(n):
    totalCube = 0
    for i in range(n+1):
        totalCube = totalCube + i**3
    return totalCube


def main():
    print("This program sums the first N numbers and sum of their cubes")
    theNValue = eval(input("Please enter a positive integer: "))
    if theNValue < 0:
        print("You entered a number, which is not a positive integer.")
        return
  
    print("The sum of first ",theNValue, " positive integers is: ", sumN(theNValue))
    print("The sum of cubes of first ",theNValue, " positive integers is: ", sumNCubes(theNValue))   

    
main()

