# -*- coding: utf-8 -*-
"""
Created on Sun Jun  9 08:05:50 2019
Assignment 6 - Question 1
This program calculates the letter grade from a given score
@author: vishal_bhalla
"""

def letterGrade(score):
    grade = ''
    if score >= 93:
        grade = 'A'
    elif score >= 90 and score < 93:
        grade = 'A-'
    elif score >= 86 and score < 90:
        grade = 'B+'
    elif score >= 83 and score < 86:
        grade = 'B'
    elif score >= 80 and score < 83:
        grade = 'B-'
    elif score >= 76 and score < 80:
        grade = 'C+'
    elif score >= 73 and score < 76:
        grade = 'C'
    elif score >= 70 and score < 73:
        grade = 'C-'
    elif score >= 67 and score < 70:
        grade = 'D+'
    elif score >= 60 and score < 67:
        grade = 'D'
    else:
        grade = 'F'
    return grade
    

def main():
    lGrade = ''
    print("The program to calculate letter grade from the total score. ")
    score = float(input("Enter your total score: "))
    if score < 0 or score > 100:
        print("Error! Score out of range.")
        return
    lGrade = letterGrade(score)
    print("Your letter grade is ", lGrade)
    
    
main()