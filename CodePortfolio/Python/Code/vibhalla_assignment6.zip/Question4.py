# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 22:34:30 2019
Assignment 6 - Question 4
This program keeps score in a game
@author: vishal_bhalla
"""

def point():
    player = input("Who wins a point, player A or B? ")
    if player.upper() == "A":
        return "A"
    elif player.upper() == "B":
        return "B"
    else:
        print("Incorrect Player Entered")
        return "E"
    

def game():
    scrA = 0
    scrB = 0
    for x in range (0,15,1):
        win = point()
        if win == "A":
            scrA = scrA + 1
        elif win == "B":
            scrB = scrB + 1
        print("A score ", scrA)
        print("B score ", scrB)
        if (((scrA >= 3 or scrB >= 3) and abs(scrA - scrB) >= 2) 
        or (scrA == 7 or scrB == 7)):
            break
    return "A" if scrA > scrB else "B"

def main():
    print("The program keeps score in a game.")
    winner = game()
    print("The winner is player ", winner , "!" )
    
main()