# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 23:30:02 2019
Assignment 6 - Question 5
This program validates the passwords
@author: vishal_bhalla
"""
def chkPass(pswd):
    alwdChar = ["$","#","@"]
    splChar = False
    numb = False
    retMsg = "You entered a valid password."
    if len(pswd) < 4:
        retMsg = "Error: The password has less than 4 characters!"
        return retMsg
    if len(pswd) > 8:
        retMsg = "Error: The password has greater than 8 characters!"
        return retMsg
    if not pswd[0].isalpha():
        retMsg = "Error: The first character is not an alphabet!"
        return retMsg
    for c in pswd:
        if c.isdigit():
            numb = True
        if c in alwdChar:
            splChar = True
    if not numb:
        retMsg = "Error: There is no numeric character in the password!"
        return retMsg
    if not splChar:
        retMsg = "Error: The password does not have at least one character from [$#@]!"
        return retMsg
    return retMsg    
    
def main():
    print("This program checks passwords")
    passwd = input("Please enter a password: ")
    status=chkPass(passwd)
    print(status)
    
main()