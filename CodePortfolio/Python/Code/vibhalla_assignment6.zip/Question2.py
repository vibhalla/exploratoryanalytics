# -*- coding: utf-8 -*-
"""
Created on Sun Jun  9 22:59:45 2019
Assignment 6 - Question 2
This program calculates and evaluates the BMI
@author: vishal_bhalla
"""

def bodyMassIndex(height,weight):
    htMts = round(height/39.37,2)
    wtKgs = round(weight/2.205)
    BMI = wtKgs/(htMts**2)
    return BMI


def main():
    bmi = ''
    print("The program to calculate and evaluate body mass index. ")
    htInch = eval(input("Enter your height in inches: "))
    wtPounds = eval(input("Enter your weight in pounds: "))
    if (type(htInch) != int or type(wtPounds) != int ):
        print(" Non integer value entered" )
        return
    if (htInch < 0 or wtPounds < 0):
        print("Negative value entered for weight or height")
        return
    
    bmi = round(bodyMassIndex(htInch,wtPounds),2)
    if bmi >= 19 and bmi <=25:
        print("Your BMI is ", bmi ," you are in a healthy range!")
    elif bmi > 25:
        print("Your BMI is ", bmi ," you are above the healthy range!")
    else:
        print("Your BMI is ", bmi ," you are below the healthy range!")
    
    
main()