# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 05:56:06 2019
Assignment 6 - Question 3
This program checks if the date entered us a valid date for a leap year
@author: vishal_bhalla
"""
def inDate(dateList):
    month = input("Please enter a month:")
    day = eval(input("Enter a day:"))
    year = eval(input("Enter a year:"))
    dateList = [month,day,year]
    return dateList


def isMonth(month):
    chkMnth = False
    mnthList = ["January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"]
    for m in mnthList:
        if m.upper() == month.upper():
            chkMnth = True
            break

    return chkMnth


def isDay(month,day):
    if type(day) != int or day < 1:
        print("Day must be a positive integer value")
        return False
    if day <= 31 and month.lower() in ["january", "march", "may", "july", "august", 
                               "october", "december"]:
        return True
    elif day <= 29 and month.lower() == "february":
        return True
    elif day <= 30 and month.lower() in ["april", "june", "september", "november"]:
        return True
    else:
        return False


def isLeapYear(year):
    chkLeap = False
    if year%100 == 0 and year%400 != 0:
        chkLeap = False
    elif year%4 == 0:
        chkLeap = True
    return chkLeap


def main():
    dateLst = []
    print("The program determines a valid date in a leap year.")
    dateLst = inDate(dateLst)
    month = dateLst[0]
    day = dateLst[1]
    year = dateLst[2]

    # Check if the year is positive integer between 1 - 2019. If not quit.
    if (year < 1 or year > 2019 or type(year) != int):
        print("Invalid Year Entered")
        return

    # Check if the year is Leap Year. If not quit.
    leapYear = isLeapYear(year)
    if not leapYear:
        print("Year entered is not a leap year")
        return

    # Check if the month is valid. If not quit.
    validMnth = isMonth(month)
    if not validMnth:
        print("Invalid month entered!")
        return

    # Check if the day is valid. If not quit.
    validDay = isDay(month,day)
    if not validDay:
        print("Invalid day entered!")
        return 

    if (leapYear and validMnth and validDay):
        print("You entered a valid date in a leap year.")

main()