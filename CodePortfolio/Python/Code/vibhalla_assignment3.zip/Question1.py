"""
Created on Thu May 23 06:31:21 2019
Assignment 3 - Question 1
This program computes the Wind Chill Index given the temprature and wind speed
@author: vishal_bhalla
"""
import math

windChill = 0

def windChillIndex(temp,wind):
    windChill = (35.74 + (0.6215*temp)-(35.75*math.pow(wind,0.16)) + 
                 (0.4275*(temp*math.pow(wind,0.16))))
    return round(windChill,1)

def main():
    print("This program calculates the wind chill.")
    temp = eval( input("Enter the temprature in degrees Fahrenheit: " ))
    wind = eval( input("Enter the wind speed in miles per hour: " ))
    windChill = windChillIndex(temp,wind)
    print("The Wind Chill Index is ", windChill)
    
main()
    