"""
Created on Thu May 23 22:08:21 2019
Assignment 3 - Question 3_1
This program prints the numbers divisible by 3
@author: vishal_bhalla
"""

def main():
    print("This program prints the numbers divisible by 3.")
    num = eval( input("Enter a positive integer: " ))
    print("Numbers between 1 and",num, " divisible by 3:")
    for i in range(1,num+1,1):
        if i%3 == 0:
            print(i)
    
main()
    