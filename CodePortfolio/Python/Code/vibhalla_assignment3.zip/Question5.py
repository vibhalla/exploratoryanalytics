"""
Created on Thu May 23 22:33:03 2019
Assignment 3 - Question 5
This program calculates the ratio of total of even number to the total of all numbers
@author: vishal_bhalla
"""

def main():
    strt = 0
    last = 0
    evenTotal = 0
    total = 0
    ratio = 0
    start = eval( input("Enter start number of a range: " ))
    last = eval( input("Enter ending number of a range: " ))
    for i in range(start,last+1,1):
        total = total + i
        if i%2 == 0:
            evenTotal = evenTotal + i
    ratio = round((evenTotal/total),3)
    print("Ratio of sum of even numbers to sum of all numbers in the range is ",ratio)
    
main()
    