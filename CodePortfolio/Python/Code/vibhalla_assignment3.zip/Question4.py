"""
Created on Thu May 23 22:25:00 2019
Assignment 3 - Question 4
This program calculates the sum of numbers entered by user
@author: vishal_bhalla
"""

def main():
    count = 0
    total = 0
    print("The program calculates the sum of numbers entered by the user")
    count = eval( input("How many numbers you want to sum up? " ))
    for i in range(1,count+1,1):
        num = 0
        num = eval( input("Enter the next number:"))
        total = total + num
    if count == 1:
        print("The sum of ",count, " number is the number itself:",total)
    else:
        print("The sum of ",count, " numbers is :",total)
    
main()
    