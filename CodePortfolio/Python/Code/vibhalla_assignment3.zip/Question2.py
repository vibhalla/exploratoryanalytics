"""
Created on Thu May 23 07:09:21 2019
Assignment 3 - Question 2
This program computes the length of the ladder given the height and angle
@author: vishal_bhalla
"""
import math

pi = 3.14
length = 0

def ladderLengthCalc(height,angle):
    angleRadians = (pi/180)*angle
    ladderLength = height/(math.sin(angleRadians))
    return round(ladderLength,2)

def main():
    print("This program calculates the length of the ladder.")
    height = eval( input("Enter the height in feet: " ))
    angle = eval( input("Enter the angle in degrees: " ))
    ladderLength = ladderLengthCalc(height,angle)
    print("The length of the ladder is ", ladderLength)
    
main()
    